from django.apps import AppConfig


class DjangoAppPermissionsAccessRequestConfig(AppConfig):
    name = 'django_app_permissions_access_request'
